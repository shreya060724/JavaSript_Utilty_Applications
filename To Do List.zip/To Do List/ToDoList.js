// Initialize the todoList from local storage or use a default value
let todoList = JSON.parse(localStorage.getItem('todoList')) || [
  { item: 'Buy Milk', dueDate: '2024-07-22' },
  { item: 'Eggs', dueDate: '2024-07-22' }
];

// Display items on page load
displayItems();

// Add todo item to the list
function addToDo() {
  let inputElement = document.querySelector('#todo-input');
  let dateElement = document.querySelector('#todo-date');
  let todoItem = inputElement.value;
  let todoDate = dateElement.value;
  
  if (todoItem && todoDate) { // Ensure both fields are not empty
    todoList.push({ item: todoItem, dueDate: todoDate });
    inputElement.value = '';
    dateElement.value = '';
    
    saveToLocalStorage(); // Save to local storage
    displayItems();
  }
}

// Display all items in the todo list
function displayItems() {
  let containerElement = document.querySelector('.todo-container');
  let newHtml = '';

  for (let i = 0; i < todoList.length; i++) {
    let { item, dueDate } = todoList[i];
    newHtml += `
      <span>${item}</span>
      <span>${dueDate}</span>
      <button class="btn-delete" onclick="deleteItem(${i})">Delete</button>
    `;
  }
  
  containerElement.innerHTML = newHtml;
}

// Save the current state of todoList to local storage
function saveToLocalStorage() {
  localStorage.setItem('todoList', JSON.stringify(todoList));
}

// Delete an item from the todo list
function deleteItem(index) {
  todoList.splice(index, 1);
  saveToLocalStorage(); // Save to local storage
  displayItems();
}
