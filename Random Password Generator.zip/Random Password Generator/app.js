const pass=document.querySelector(".generateContainer");
const length=12;
const uppercase="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const lowercase= "abcdefghijklmnopqrstuvwxyz";
const symbol="!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~";
const num = "0123456789";
const allChars=uppercase+lowercase+num+symbol;
const passBox=document.querySelector("#text");

function createPassword(){
  let password="";
  password+=uppercase[Math.floor(Math.random()*uppercase.length)];
  password+=lowercase[Math.floor(Math.random()*lowercase.length)];
  password+=symbol[Math.floor(Math.random()*symbol.length)];
  password+=num[Math.floor(Math.random()*num.length)];
  while(length>password.length){
    password+=allChars[Math.floor(Math.random()*allChars.length)];
  }passBox.value=password;
  
}

function copyPassword(){
  passBox.select();
  document.execCommand("copy");
}